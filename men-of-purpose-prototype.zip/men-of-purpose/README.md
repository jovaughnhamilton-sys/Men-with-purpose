# Men of Purpose — Free-for-Everyone Prototype

**An Initiative of Triple J's Solutions Enterprises Ltd.**

## Current build (October 2026)
A static, mobile-friendly progressive web app prototype with forest-green and gold branding. It contains a home screen, daily devotional reader, seven original sample devotionals, a 40-day topic roadmap (days 8–40 are not yet written), a prayer journal, sharing, and local progress tracking. NLT Scripture **references** are provided; copyrighted NLT passages are not reproduced. No subscription, advertising, account, analytics, or server is included.

## Run and test locally — $0
From the parent directory, run `python -m http.server 8000`, then open `http://localhost:8000/men-of-purpose/`. For phone testing and offline install, use HTTPS hosting; opening `index.html` directly does not fully enable service workers. Journal and progress data are stored on each device in browser localStorage and can be lost if browser data is cleared. Do not use the journal for highly sensitive information.

## Publish a free public beta — $0
1. Create a free GitHub account, if needed.
2. Create a public repository, for example `men-of-purpose`.
3. Upload the **contents** of this folder to the repository root (`index.html`, `manifest.webmanifest`, `sw.js`, `icon.svg`). Do not upload the zip as a single file.
4. In repository Settings > Pages, choose Deploy from a branch, select `main` and `/ (root)`, and save. Wait for the HTTPS site URL GitHub displays.
5. Open the URL on Android and iPhone. Use the browser's Add to Home Screen option if available. Verify the home page, seven readings, journal, progress and sharing.
6. Invite 10–20 volunteers to test. Tell them it is a prototype, that journal entries stay on their devices, and that there are only seven completed readings.

GitHub Pages availability and settings can change; check the provider's current terms. This prototype is not yet published online by ChatGPT.

## Build milestones
**October:** review content and usability; finish all 40 original readings, one at a time; test the current web prototype.
**November:** free HTTPS public beta, reader feedback, basic accessibility fixes.
**December:** privacy policy, app-store descriptions and screenshots, production icon assets, device tests, Android/iOS packaging plan, publisher/company verification.
**January 2027 target:** pay required developer fees only when ready; complete any mandated testing; submit for review. App-store approval is not guaranteed.

## Store strategy and cost
The app stays free for users forever: no subscriptions, in-app purchases or ads. Estimated developer registration: Google Play US$25 one-time; Apple Developer Program US$99/year, before applicable taxes, changes or additional costs. Target initial publishing budget: about US$124 plus contingency. Verify latest policies and fees before payment.

A progressive web app does not automatically become a store-ready native app. Android and iOS packaging, store policies, app icons, privacy disclosures, testing and developer identity verification are separate work. Organization enrollment may require additional legal documentation and a D-U-N-S number. Apple may reject a thin website wrapper; plan for a genuine app-like experience and native capabilities.

## Copyright and editorial rules
Do not embed the full NLT Bible or lengthy NLT excerpts without appropriate rights. Keep original devotional text and NLT references or use authorized links while seeking licensing guidance. Obtain review by a trusted pastor or biblical editor before public release.

## Next technical tasks
- Finish all 40 readings and ensure no placeholder day is presented as a completed reading.
- Add accessible focus states, screen-reader labels, font-size controls and contrast checks.
- Test saving, offline behavior, progress reset, sharing and home-screen install on real devices.
- Add a clear privacy page and a feedback contact channel.
- Evaluate Expo/React Native for eventual store builds, without assuming that the current static prototype is native.
